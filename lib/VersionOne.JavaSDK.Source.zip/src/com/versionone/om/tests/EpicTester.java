package com.versionone.om.tests;

import java.util.Date;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.om.AssetID;
import com.versionone.om.Epic;
import com.versionone.om.Member;


/**
 * Epic tester
 */
//TODO for raising test coverage
public class EpicTester extends BaseSDKTester {

    @Test
    public void testCreateAndDeleteEpic() {
        final String epicName = "new epic for testing " + new Date().getTime();
        final String epicDescription = "new epic description " + new Date().getTime();
        final String epicChildName = "new epic child for testing " + new Date().getTime();
        final String requestedBy = "Requested by";
        final String reference = "Reference";
        final double estimate = 10.00;
        final String inProgress = "In Progress";
        Member andre = getInstance().get().memberByID("Member:1000");
        AssetID epicId = null;
        Epic epicChild;

        Epic epic = getSandboxProject().createEpic(epicName);
        epic.setCustomer(andre);
        epic.setDescription(epicDescription);
        epic.setEstimate(estimate);
        epic.setRequestedBy(requestedBy);
        epic.getStatus().setCurrentValue(inProgress);
        epic.setReference(reference);

        epic.save();

        epicId = epic.getID();

        resetInstance();

        Epic actuialEpic = getInstance().get().epicByID(epicId);

        Assert.assertEquals(epicName, actuialEpic.getName());
        Assert.assertEquals(epicDescription, actuialEpic.getDescription());
        Assert.assertEquals(andre, actuialEpic.getCustomer());
        Assert.assertEquals(requestedBy, actuialEpic.getRequestedBy());
        Assert.assertEquals(inProgress, actuialEpic.getStatus().getCurrentValue());
        Assert.assertEquals(reference, actuialEpic.getReference());
        Assert.assertEquals(estimate, actuialEpic.getEstimate(),
                ESTIMATES_PRECISION);
        Assert.assertTrue(actuialEpic.isActive());
        Assert.assertTrue(actuialEpic.canDelete());
        Assert.assertTrue(actuialEpic.canGenerateChildEpic());
        Assert.assertTrue(actuialEpic.canGenerateChildStory());

        actuialEpic.delete();
        getSandboxProject().delete();

        resetInstance();

        actuialEpic = getInstance().get().epicByID(epicId);

        Assert.assertNull(actuialEpic);
    }

}
