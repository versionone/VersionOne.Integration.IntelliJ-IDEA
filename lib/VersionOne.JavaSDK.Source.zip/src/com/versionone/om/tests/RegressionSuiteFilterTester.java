package com.versionone.om.tests;

import com.versionone.Oid;
import com.versionone.apiclient.OidException;
import com.versionone.om.Member;
import com.versionone.om.RegressionPlan;
import com.versionone.om.RegressionSuite;
import com.versionone.om.filters.RegressionSuiteFilter;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class RegressionSuiteFilterTester extends BaseSDKTester {
    RegressionPlan regressionPlan;
    RegressionPlan regressionPlan2;
    private final String RegressionSuiteName = "Regression Suite";

    @After
    public void after() {
        getEntityFactory().dispose();
        getSandboxProject().delete();
    }
    
    @Before
    public void before() {
        regressionPlan = getEntityFactory().createRegressionPlan("Test plan", getSandboxProject());
        regressionPlan2 = getEntityFactory().createRegressionPlan("RegPlanFake", getSandboxProject());
    }

    @Test
    public void getRegressionSuiteWithNullFilterTest() {
        Collection<RegressionSuite> suites = getInstance().get().regressionSuites(null);
        RegressionSuite suite = getEntityFactory().createRegressionSuite(RegressionSuiteName, regressionPlan);
        Collection<RegressionSuite> updatedSuites = getInstance().get().regressionSuites(null);

        Assert.assertEquals(1, updatedSuites.size() - suites.size());
        ListAssert.contains(suite, updatedSuites);
    }

    @Test
    public void getRegressionSuitesByOwnerTest() throws OidException {
        Member owner = getEntityFactory().createMember("SuiteOwner");
        Member nobody = getEntityFactory().createMember("OtherOwner");

        Map<String, Object> attributes = new HashMap<String, Object>();
        attributes.put("Owner", Oid.fromToken(owner.getID().toString(),
                                              getInstance().getApiClient().getMetaModel()));
        RegressionSuite suite = getEntityFactory().createRegressionSuite(RegressionSuiteName, regressionPlan,
                                                                        attributes);

        RegressionSuiteFilter filter = new RegressionSuiteFilter();
        filter.owners.add(owner);
        Collection<RegressionSuite> suites = getInstance().get().regressionSuites(filter);
        Assert.assertEquals(1, suites.size());
        ListAssert.contains(suite, suites);

        filter = new RegressionSuiteFilter();
        filter.owners.add(nobody);
        suites = getInstance().get().regressionSuites(filter);
        Assert.assertEquals(0, suites.size());
    }

    @Test
    public void getRegressionSuitesWithSpecificRegressionPlanTest() throws OidException {
        Map<String, Object> attributes = new HashMap<String, Object>();
        attributes.put("RegressionPlan", Oid.fromToken(regressionPlan.getID().toString(),
                                                       getInstance().getApiClient().getMetaModel()));
        RegressionSuite suite = getEntityFactory().createRegressionSuite(RegressionSuiteName, regressionPlan,
                                                                        attributes);

        RegressionSuiteFilter filter = new RegressionSuiteFilter();
        filter.regressionPlan.add(regressionPlan);
        Collection<RegressionSuite> suites = getInstance().get().regressionSuites(filter);
        Assert.assertEquals(1, suites.size());
        ListAssert.contains(suite, suites);

        filter = new RegressionSuiteFilter();
        filter.regressionPlan.add(regressionPlan2);
        suites = getInstance().get().regressionSuites(filter);
        Assert.assertEquals(0, suites.size());
    }

    @Test
    public void getRegressionSuitesByPlanTest() {
        RegressionSuite suite = getEntityFactory().createRegressionSuite(RegressionSuiteName, regressionPlan, null);

        RegressionSuiteFilter filter = new RegressionSuiteFilter();
        filter.regressionPlan.add(regressionPlan);
        Collection<RegressionSuite> suites = getInstance().get().regressionSuites(filter);
        Assert.assertTrue(suites.size() > 0);
        ListAssert.contains(suite, suites);
    }

    @Test
    public void getRegressionSuitesByEstimateTest() {
        double estimate = 14;
        Map<String, Object> attributes = new HashMap<String, Object>();
        attributes.put("Estimate", estimate);
        RegressionSuite suite = getEntityFactory().createRegressionSuite(RegressionSuiteName, regressionPlan,
                                                                        attributes);

        RegressionSuiteFilter filter = new RegressionSuiteFilter();
        filter.estimate.add(estimate);
        Collection<RegressionSuite> suites = getInstance().get().regressionSuites(filter);
        Assert.assertTrue(suites.size() > 0);
        ListAssert.contains(suite, suites);
    }

    @Test
    public void getRegressionSuitesWithReferenceTest() {
        String reference = "TestRefence-1010";
        Map<String, Object> attributes = new HashMap<String, Object>();
        attributes.put("Reference", reference);
        RegressionSuite suite = getEntityFactory().createRegressionSuite(RegressionSuiteName, regressionPlan,
                                                                        attributes);

        RegressionSuiteFilter filter = new RegressionSuiteFilter();
        filter.reference.add(reference);
        Collection<RegressionSuite> suites = getInstance().get().regressionSuites(filter);
        Assert.assertTrue(suites.size() > 0);
        ListAssert.contains(suite, suites);

        filter = new RegressionSuiteFilter();
        filter.reference.add("WrongReference");
        suites = getInstance().get().regressionSuites(filter);
        Assert.assertEquals(0, suites.size());
    }

    @Test
    public void getRegressionSuitesByIDTest() {
        RegressionSuite suite = getEntityFactory().createRegressionSuite(RegressionSuiteName, regressionPlan);
        String displayId = suite.getDisplayID();

        RegressionSuiteFilter filter = new RegressionSuiteFilter();
        filter.displayID.add(displayId);
        Collection<RegressionSuite> suites = getInstance().get().regressionSuites(filter);
        Assert.assertEquals(1, suites.size());
        ListAssert.contains(suite, suites);

        filter = new RegressionSuiteFilter();
        filter.displayID.add("WrongNumber");
        suites = getInstance().get().regressionSuites(filter);
        Assert.assertEquals(0, suites.size());
    }
}
