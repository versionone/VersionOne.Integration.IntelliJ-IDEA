package com.versionone.om.tests;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.om.Epic;
import com.versionone.om.Story;
import com.versionone.om.Theme;
import com.versionone.om.Workitem;
import com.versionone.om.filters.DefectFilter;
import com.versionone.om.filters.StoryFilter;

public class WorkitemFilterTester extends PrimaryWorkitemFilterTesterBase {

    private DefectFilter getFilter() {
        DefectFilter filter = new DefectFilter();
        filter.project.add(sandboxProject);
        return filter;
    }

    @Test
    public void testDetailEstimate() {
        Story story = getSandboxProject().createStory("Story 1");

        // story.setDetailEstimate(1.0);
        // story.save();

        StoryFilter filter = new StoryFilter();
        filter.detailEstimate.add(1.0);
        Assert.assertEquals(0, getInstance().get().story(filter)
                .size());
    }

    @Test
    public void testReference() {
        DefectFilter filter = getFilter();
        filter.reference.add(REFERENCE);
        Assert.assertEquals(1, getInstance().get().defects(filter)
                .size());
    }

	@Test
	public void NoThemeAmongWorkitems()
	{
		Theme theme = getSandboxProject().createTheme("A Theme");

		resetInstance();

		ListAssert.notcontains(theme.getName(), getInstance().get().workitems(null), new EntityToNameTransformer<Workitem>());
	}

	@Test
	public void NoEpicAmongWorkitems()
	{
		Epic epic = getSandboxProject().createEpic("War And Piece");

		resetInstance();

		ListAssert.notcontains(epic.getName(), getInstance().get().workitems(null), new EntityToNameTransformer<Workitem>());
	}
    

}
