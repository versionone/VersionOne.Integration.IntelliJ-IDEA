package com.versionone.om.tests;

import com.versionone.DB;
import static com.versionone.apiclient.FilterTerm.Operator.GreaterThan;
import static com.versionone.apiclient.FilterTerm.Operator.GreaterThanOrEqual;
import static com.versionone.apiclient.FilterTerm.Operator.LessThan;
import static com.versionone.apiclient.FilterTerm.Operator.LessThanOrEqual;
import com.versionone.om.Effort;
import com.versionone.om.Story;
import com.versionone.om.Task;
import com.versionone.om.filters.EffortFilter;

import org.junit.Test;

import java.util.Calendar;
import java.util.Collection;

public class EffortFilterTester extends BaseSDKTester {

    @Test
    public void testDate() {
        final Story story = getSandboxProject().createStory("Story1");
        final Task task = story.createTask("Task2");
        final Effort effort1 = task.createEffort(1d);
        final DB.DateTime effort1Date = effort1.getDate();
        final DB.DateTime effort2Date = effort1Date.add(Calendar.DAY_OF_YEAR, 1);
        final Effort effort2 = task.createEffort(2d);
        effort2.setDate(effort2Date);
        effort2.save();
        resetInstance();

        EffortFilter filter = new EffortFilter();
        filter.date.addTerm(GreaterThan, effort1Date);
        Collection<Effort> efforts = getInstance().get().effortRecords(filter);
        ListAssert.notcontains(effort1, efforts);
        ListAssert.contains(effort2, efforts);

        filter.date.clear();
        filter.date.addTerm(LessThan, effort2Date);
        efforts = getInstance().get().effortRecords(filter);
        ListAssert.contains(effort1, efforts);
        ListAssert.notcontains(effort2, efforts);

        filter.date.clear();
        filter.date.addTerm(LessThanOrEqual, effort1Date);
        efforts = getInstance().get().effortRecords(filter);
        ListAssert.contains(effort1, efforts);
        ListAssert.notcontains(effort2, efforts);

        filter.date.clear();
        filter.date.addTerm(GreaterThanOrEqual, effort2Date);
        efforts = getInstance().get().effortRecords(filter);
        ListAssert.notcontains(effort1, efforts);
        ListAssert.contains(effort2, efforts);

        story.delete();
        getSandboxProject().delete();
    }
}