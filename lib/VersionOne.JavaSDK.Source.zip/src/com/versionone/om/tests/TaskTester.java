/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om.tests;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.versionone.om.Project;
import com.versionone.om.Retrospective;
import org.junit.Assert;
import org.junit.Test;

import com.versionone.om.Story;
import com.versionone.om.Task;
import com.versionone.om.filters.TaskFilter;

public class TaskTester extends BaseSDKTester {

    private Task[] getTaskArrayFromFilter(TaskFilter filter) {
        Collection<Task> tasks = getInstance().get().tasks(filter);
        Task[] taskArray = new Task[tasks.size()];
        return tasks.toArray(taskArray);
    }

    @Test
    public void testOrder() {
        final String strTaskName1 = "Task 1";
        final String strTaskName2 = "Task 2";

        Story story = getSandboxProject().createStory("Task Order Test");

        Task task1 = story.createTask(strTaskName1);
        Task task2 = story.createTask(strTaskName2);

        TaskFilter filter = new TaskFilter();
        filter.parent.add(story);
        filter.orderBy.add("RankOrder");
        Task[] taskArray = getTaskArrayFromFilter(filter);
        Assert.assertEquals(strTaskName1, taskArray[0].getName());
        Assert.assertEquals(strTaskName2, taskArray[1].getName());

        task2.getRankOrder().setAbove(task1);

        taskArray = getTaskArrayFromFilter(filter);
        Assert.assertEquals(strTaskName2, taskArray[0].getName());
        Assert.assertEquals(strTaskName1, taskArray[1].getName());
    }

    @Test
    public void testCreateTaskWithAttributes() {
        final String name = "Task Name";
        final Story story = getSandboxProject().createStory("Task Order Test");
        final String description = "Test for Task creation with required attributes";
        Map<String, Object> attributes = new HashMap<String, Object>();
        attributes.put("Description", description);

        Task task = story.createTask(name, attributes);

        Assert.assertEquals(name, task.getName());
        Assert.assertEquals(description, task.getDescription());

        task.delete();
    }
}
