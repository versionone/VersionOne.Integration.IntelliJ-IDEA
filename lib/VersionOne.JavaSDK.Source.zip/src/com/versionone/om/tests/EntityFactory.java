package com.versionone.om.tests;

import com.versionone.om.*;

import java.util.*;

/**
 * Entity creation factory that cleans up created objects when disposed.
 * If you create entities manually, do not forget to handle them on your own.
 */
class EntityFactory {
    private final Stack<BaseAsset> entities = new Stack<BaseAsset>();
    private final V1Instance instance;

    private final Random random = new Random();

    private V1Instance getInstance() {
        return instance;
    }

    EntityFactory(V1Instance instance) {
        this.instance = instance;
    }

    RegressionPlan createRegressionPlan(String name, Project project) {
        return createRegressionPlan(name, project, new HashMap<String, Object>());
    }

    RegressionPlan createRegressionPlan(String name, Project project, Map<String, Object> attributes) {
        RegressionPlan plan = getInstance().create().regressionPlan(name, project, attributes);
        registerForDisposal(plan);

        return plan;
    }

    RegressionSuite createRegressionSuite(String name, RegressionPlan regressionPlan) {
        return createRegressionSuite(name, regressionPlan, null);
    }

    RegressionSuite createRegressionSuite(String name, RegressionPlan regressionPlan, Map<String, Object> attributes) {
        RegressionSuite suite = getInstance().create().regressionSuite(name, regressionPlan, attributes);
        registerForDisposal(suite);

        return suite;
    }

    TestSet createTestSet(String name, RegressionSuite suite, Map<String, Object> attributes) {
        TestSet testSet = getInstance().create().testSet(name, suite, suite.getRegressionPlan().getProject(),
                                                         attributes);
        registerForDisposal(testSet);

        return testSet;
    }

    TestSet createTestSet(String name, RegressionSuite suite) {
        return createTestSet(name, suite, null);
    }

    Member createMember(String name) {
        String randomString = Integer.toString(random.nextInt());
        Member member = getInstance().create().member(name, randomString);
        registerForDisposal(member);

        member.save();
        return member;
    }

    RegressionTest createRegressionTest(String name, Project project) {
        return createRegressionTest(name, project, null);
    }

    RegressionTest createRegressionTest(String name, Project project, Map<String, Object> attributes) {
        RegressionTest regressionTest = getInstance().create().regressionTest(name, project, attributes);
        registerForDisposal(regressionTest);

        return regressionTest;
    }

    RegressionTest createRegressionTest(Test test) {
        RegressionTest regressionTest = getInstance().create().regressionTest(test);
        registerForDisposal(regressionTest);

        return regressionTest;
    }

    Test createTest(String name, PrimaryWorkitem primaryWorkitem) {
        Test test = getInstance().create().test(name, primaryWorkitem);
        registerForDisposal(test);

        return test;
    }

    Story createStory(String name, Project scope) {
        Story story = getInstance().create().story(name, scope);
        registerForDisposal(story);

        return story;
    }

    /**
     * Register entity for dispose it at the end.
     *
     * @param asset Item to register.
     */
    void registerForDisposal(BaseAsset asset) {
        entities.push(asset);
    }

    /**
     * Remove entities that have been registered for disposal.
     */
    void dispose() {
        while (entities.size() > 0) {
            BaseAsset item = entities.pop();

            item.delete();
        }
    }
}