/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om.tests;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.om.AssetID;
import com.versionone.om.TestSuite;

public class TestSuiteTester extends BaseSDKTester {

    @Test
    public void testCreateAndRetrieveTestSuite() {
        final String suiteName = "The Suite of Tests";
        final String reference = "ABC123";

        AssetID id = getInstance().create().
                testSuite(suiteName, reference).getID();
        resetInstance();

        TestSuite testSuite = getInstance().get().testSuiteByID(id);
        Assert.assertEquals(testSuite.getName(), suiteName);
        Assert.assertEquals(testSuite.getReference(), reference);
        Assert.assertTrue(
                "Expected to find newly saved TestSuite in the enumerable of " +
                        "TestSuites on V1Instance.",
                findRelated(testSuite, getInstance().getTestSuites()));

        Assert.assertNull(testSuite.getURL());
    }
}
