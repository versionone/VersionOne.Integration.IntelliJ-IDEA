/*(c) Copyright 2008, VersionOne, Inc. All rights reserved. (c)*/
package com.versionone.om.tests;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.om.Defect;
import com.versionone.om.filters.DefectFilter;

public class DefectFilterTester extends PrimaryWorkitemFilterTesterBase {

    private DefectFilter getFilter() {
        DefectFilter filter = new DefectFilter();
        filter.project.add(sandboxProject);
        return filter;
    }

    @Test
    public void testFoundBy() {
        DefectFilter filter = getFilter();
        filter.foundBy.add("Joe");
        Assert.assertEquals("Should be one defect FoundBy \"Joe\"",
                1, getInstance().get().defects(filter).size());
    }

    @Test
    public void testType() {
        DefectFilter filter = getFilter();
        filter.type.add("Code");
        Assert.assertEquals("Should be one defect of Type \"Code\"",
                1, getInstance().get().defects(filter).size());
    }

    public void testTypeAndFoundBy() {
        DefectFilter filter = getFilter();
        filter.type.add("Code");
        filter.foundBy.add("Bob");
        Assert.assertEquals("Should be one defect of Type \"Code\" and FoundBy \"Bob\"",
                1, getInstance().get().defects(filter).size());

        filter = getFilter();
        filter.type.add("Documentation");
        filter.foundBy.add("Bob");
        Assert.assertEquals("Should be no defects of Type \"Documentation\" and FoundBy \"Bob\"",
                0, getInstance().get().defects(filter).size());
    }

    @Test
    public void testFoundInBuild() {
        DefectFilter filter = getFilter();
        filter.foundInBuild.add("1.0.0.0");
        Assert.assertEquals("Should be two defects FoundInBuild \"1.0.0.0\"",
                2, getInstance().get().defects(filter).size());
    }

    @Test
    public void testEnvironment() {
        DefectFilter filter = getFilter();
        filter.environment.add("Windows");
        Assert.assertEquals("Should be one defect with Environment of \"Windows\"",
                1, getInstance().get().defects(filter).size());
    }

    @Test
    public void testResolvedInBuild() {
        DefectFilter filter = getFilter();
        filter.resolvedInBuild.add("1.0.0.2");
        filter.orderBy.add("ResolvedInBuild");
        Assert.assertEquals("Should be one defect ResolvedInBuild \"1.0.0.2\"",
                1, getInstance().get().defects(filter).size());
    }

    @Test
    public void testVerifiedBy() {
        DefectFilter filter = getFilter();
        filter.verifiedBy.add(null);
        filter.verifiedBy.add(danny);
        Assert.assertEquals("Should be two defects VerifiedBy Danny or no one.",
                2, getInstance().get().defects(filter).size());
    }

    @Test
    public void testResolutionReason() {
        DefectFilter filter = getFilter();
        filter.resolutionReason.add("Fixed");
        Assert.assertEquals("Should be one defect of ResolutionReason \"Fixed\"",
                1, getInstance().get().defects(filter).size());
    }

    @Test
    public void testEstimate() {
        DefectFilter filter = getFilter();
        filter.estimate.add(1.0D);
        filter.estimate.add(null);
        Assert.assertEquals(2, getInstance().get().defects(filter).size());
    }
    
	@Test
	public void testNoProjectAmongDefects()
	{
		String sandboxName = getSandboxProject().getName();

		resetInstance();

		ListAssert.notcontains(sandboxName, getInstance().get().baseAssets(new DefectFilter()), new EntityToNameTransformer<Defect>());
	}
    
}
