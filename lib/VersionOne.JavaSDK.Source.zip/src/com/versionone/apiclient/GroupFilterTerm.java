package com.versionone.apiclient;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for grouping filter terms (i.e and, or)
 * @author jerry
 *
 */
public abstract class GroupFilterTerm implements IFilterTerm {

	List<IFilterTerm> _terms = new ArrayList<IFilterTerm>();

	public boolean hasTerm()
	{
		return _terms.size() > 0;
	}

	/**
	 * get token for this grouping
	 * @throws APIException if term has incorrect statement
	 */
	public String getToken() throws APIException {
		ArrayList<String> tokens = new ArrayList<String>();
		for(int i = 0; i < _terms.size(); ++i)
		{
			IFilterTerm term = _terms.get(i);
			String token = term.getToken();
			if (token != null)
				tokens.add(token);
		}
		return tokens.size() == 0 ? null : "(" + TextBuilder.join(tokens.toArray(), getTokenSeperator()) + ")";
	}

	abstract String getTokenSeperator();

	protected GroupFilterTerm(IFilterTerm[] terms)
	{
		for(IFilterTerm term : terms)
			if (term != null)
				_terms.add(term);
	}

	/**
	 * Create a group term from two filter terms
	 * @param term1
	 * @param term2
	 */
	public GroupFilterTerm(IFilterTerm term1, IFilterTerm term2) {
		if(null != term1)
			_terms.add(term1);
		if(null != term2)
			_terms.add(term2);
	}

	/**
	 * Create an AndFilterTerm from the array of terms
	 * @param terms
	 * @return
	 */
	public GroupFilterTerm And(IFilterTerm[] terms)
	{
		AndFilterTerm term = new AndFilterTerm(terms);
		_terms.add(term);
		return term;
	}

	/**
	 * create an OrFilterTerm from the array of terms
	 * @param terms
	 * @return
	 */
	public GroupFilterTerm Or(IFilterTerm[] terms)
	{
		OrFilterTerm term = new OrFilterTerm(terms);
		_terms.add(term);
		return term;
	}

	/**
	 * Create a filter term from the attribute definition
	 * @param def
	 * @return
	 */
	public FilterTerm Term(IAttributeDefinition def)
	{
		FilterTerm term = new FilterTerm(def);
		_terms.add(term);
		return term;
	}
}
