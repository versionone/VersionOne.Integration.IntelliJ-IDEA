package com.versionone.apiclient;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.versionone.apiclient.IAttributeDefinition.AttributeType;

/**
 * Represents one filter term on a query
 * @author jerry
 *
 */
public class FilterTerm implements IFilterTerm {

    /**
	 * Supported operations on a filter term
	 * @author jerry
	 *
	 */
	public enum Operator
	{
		/**
		 * Equals Operator (=)
		 */
		Equal,
		/**
		 * Inequality Operator (!=)
		 */
		NotEqual,
		/**
		 * Greater than operator (>)
		 */
		GreaterThan,
		/**
		 * Less than operator  (<)
		 */
		LessThan,
		/**
		 * Greater than or equal to operator (>=)
		 */
		GreaterThanOrEqual,
		/**
		 * Less than or equal to (<=)
		 */
		LessThanOrEqual,
		/**
		 * Exists
		 */
		Exists,
		/**
		 * NotExists
		 */
		NotExists
	}

	private IAttributeDefinition _def;
	private Operator _operator = Operator.Equal;
	private List<Object> _values = new ArrayList<Object>();

	/**
	 * create from an attribute definition
	 * @param def
	 */
	public FilterTerm(IAttributeDefinition def)
	{
		_def = def;
	}

	/**
	 * Create from attribute, operator, and a collection of values
	 * @param def
	 * @param operator
	 * @param values
	 */
	public FilterTerm(IAttributeDefinition def, Operator operator, Object[] values)
	{
		_def = def;
		Operate(operator, values);
	}

	/**
	 * create from attribute operator and value
	 * @param def
	 * @param operator
	 * @param value
	 */
	public FilterTerm(IAttributeDefinition def, Operator operator, Object value)
	{
		_def = def;
		Operate(operator, value);
	}

	public String getShortToken() throws APIException{
		return makeToken(false);
	}

	private String makeToken(boolean full) throws APIException{
		if (_operator == Operator.Exists){
			if ( _values.size() > 0 ){
				throw new APIException("Exists operator may not take values");
			}
			return "%2B" + _def.getToken();
		}
		else if (_operator == Operator.NotExists){
			if (_values.size() > 0){
				throw new APIException("NotExists operator may not take values");
			}
			return "-" + _def.getToken();
		}
		else if (_values.size() == 0){
			return null;
		}
		return _def.getName() + operatorToken(_operator) + TextBuilder.join(_values.toArray(), ",",
                TextBuilder.STRINGIZER_DELEGATE.build(FilterTerm.class, "Stringize"));
	}

	/**
	 * Set equality to value
	 * @param value compare to.
	 */
	public void Equal(Object value) {
		Operate(Operator.Equal, value);
	}

	/**
	 * set equality to a collection of values
	 * @param value compare to.
	 */
	public void Equal(Object[] value)
	{
		Operate(Operator.Equal, value);
	}

	/**
	 * set inequality to a value
	 * @param value compare to.
	 */
	public void NotEqual(Object value)
	{
		Operate(Operator.NotEqual, value);
	}

	/**
	 * set inequality to a collection of values
	 * @param value compare to.
	 */
	public void NotEqual(Object[] value)
	{
		Operate(Operator.NotEqual, value);
	}

	/**
	 * set greater than value
	 * @param value compare to.
	 */
	public void Greater(Object value)
	{
		Operate(Operator.GreaterThan, value);
	}

	/**
	 * set greater than multiple values
	 * @param value compare to.
	 */
	public void Greater(Object[] value)
	{
		Operate(Operator.GreaterThan, value);
	}

	/**
	 * set less than value
	 * @param value compare to.
	 */
	public void Less(Object value)
	{
		Operate(Operator.LessThan, value);
	}

	/**
	 * set less than multiple values
	 * @param value compare to.
	 */
	public void Less(Object[] value)
	{
		Operate(Operator.LessThan, value);
	}

	/**
	 * set less than or equal to value
	 * @param value compare to.
	 */
	public void LessOrEqual(Object value)
	{
		Operate(Operator.LessThanOrEqual, value);
	}

	/**
	 * set less than or equal to multiple value
	 * @param value compare to.
	 */
	public void LessOrEqual(Object[] value)
	{
		Operate(Operator.LessThanOrEqual, value);
	}

	/**
	 * set greater than or equal to value
	 * @param value compare to.
	 */
	public void GreaterOrEqual(Object value)
	{
		Operate(Operator.GreaterThanOrEqual, value);
	}

	/**
	 * set greater than or equal to multiple value
	 * @param value compare to.
	 */
	public void GreaterOrEqual(Object[] value)
	{
		Operate(Operator.GreaterThanOrEqual, value);
	}

    /**
     * Set existence of attribute.
     */
	public void Exists(){
		Operate(Operator.Exists, null);
	}

    /**
     * Set NOT existence of attribute.
     */
	public void NotExists(){
		Operate(Operator.NotExists, null);
	}

    /**
     * Set specified condition to value.
     * @param newop condition.
     * @param value compare to.
     */
	public void Operate(Operator newop, Object value){
		validate(newop);

		if (value != null){
			_values.add(value);
		}
	}

    /**
     * Set specified condition to value.
     * @param newop condition.
     * @param values compare to.
     */
	public void Operate(Operator newop, Object[] values){
		validate(newop);

		if (values != null){
			_values.addAll(Arrays.asList(values));
		}
	}

	private void validate(Operator newop) {
		if (newop == Operator.GreaterThan ||
				newop == Operator.GreaterThanOrEqual ||
				newop == Operator.LessThan ||
				newop == Operator.LessThanOrEqual)
		{
			AttributeType deftype = _def.getAttributeType();
			if (deftype != AttributeType.Date &&
					deftype != AttributeType.Numeric)
				throw new RuntimeException("Inequality Operation Not Valid For " + deftype.toString() + " AttributeType.");

		}

		if (newop != _operator)
		{
			_operator = newop;
			_values.clear();
		}
	}


	/**
	 * return the token for this term
	 * @throws APIException if {@code _values} and {@code _operator}
	 *         has incorrect condition
	 */
	public String getToken() throws APIException{
		return makeToken(true);
	}

	private static String operatorToken(Operator op)
	{
		switch(op)
		{
			case Equal :
				return "=";
			case NotEqual :
				return "!=";
			case GreaterThan :
				return ">";
			case GreaterThanOrEqual :
				return ">=";
			case LessThan :
				return "<";
			case LessThanOrEqual :
				return "<=";
		}
		return null;
	}

	/**
	 * implementation detail
	 * @param value
	 * @return quoted string of value
	 */
	public static String Stringize(Object value)
	{
		String result = value != null ? value.toString() : "";

		result = result.replace("'","''");
		result = result.replace("\"","\"\"");
		try {
			result = URLEncoder.encode(result, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			result = result.replace("+","%2B");
			result = result.replace(" ","+");
			result = result.replace("&","%26");
			result = result.replace("#","%23");
		}

		return "'" + result + "'";
	}
}
