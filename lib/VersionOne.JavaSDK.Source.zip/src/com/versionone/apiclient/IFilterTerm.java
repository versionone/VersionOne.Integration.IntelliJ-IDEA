package com.versionone.apiclient;

/**
 * Interface required for Filter Terms
 * @author jerry
 *
 */
public interface IFilterTerm {
	/**
	 * @return token
	 * @throws APIException object has incorrect statement
	 */
	public String getToken() throws APIException;
}
