package com.versionone.apiclient;

import com.versionone.Oid;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents one Asset in the VersionOne system.
 * Assets are Projects, Stories, Tasks, etc
 *
 * @author jerry
 *
 */
public class Asset {

	private Oid _oid = Oid.Null;
	private Map<String, Attribute> _attributes = new HashMap<String, Attribute>();
	private Map<String, Asset> _newAssets = new HashMap<String, Asset>();
	private IAssetType _assetType;
	private List<Asset> _children = new ArrayList<Asset>();

	/**
	 * Get type information
	 * @return
	 */
	public IAssetType getAssetType(){ return _assetType; }

	/**
	 * Get Asset Object Identifier
	 * @return
	 */
	public Oid getOid() {return _oid;}

	/**
	 * This method is used by Service after a new asset has been created.
	 * the result of create returns the oid
	 *
	 * @param value
	 * @throws OidException - when the new oid is a different type of asset
	 */
	public void setOid(Oid value) throws OidException
	{
		if(value.getAssetType() != _assetType)
			throw new OidException("Cannot change this asset's AssetType", value.getToken());
		_oid = value;
	}

	/**
	 * Get asset attributes
	 * @return
	 */
	public Map<String, Attribute> getAttributes(){ return _attributes; }

	/**
	 * Used to add new relationships
	 * get new assets
	 * @return
	 */
	public Map<String, Asset> getNewAssets() { return _newAssets; }

	/**
	 * Get child assets
	 * @return
	 */
	public List<Asset> getChildren() { return _children; }

	/**
	 * Create from Object Id
	 * @param oid
	 */
	public Asset(Oid oid)
	{
		if (oid.isNull())
			throw new java.lang.IllegalArgumentException("Cannot initialize Asset with NULL Oid");
		_oid = oid;
		_assetType = oid.getAssetType();
	}

	/**
	 * Create based on type
	 *
	 * @param assetType
	 */
	public Asset(IAssetType assetType)
	{
		_assetType = assetType;
	}

	/**
	 * set an attribute value
	 * @param attribdef attribute  definition
	 * @param value attribute value
	 */
	public void setAttributeValue(IAttributeDefinition attribdef, Object value) throws APIException
	{
		ensureAttribute(attribdef).setValue(value);
	}

	/**
	 * force an attribute to a value
	 *
	 * @param attribdef attribute definition
	 * @param value value
	 * @throws Exception
	 */
	void forceAttributeValue(IAttributeDefinition attribdef, Object value) throws APIException
	{
		ensureAttribute(attribdef).forceValue(value);
	}

	/**
	 * add an attribute value
	 *
	 * @param attribdef
	 * @param value
	 * @throws Exception
	 */
	public void addAttributeValue(IAttributeDefinition attribdef, Object value) throws APIException
	{
		ensureAttribute(attribdef).addValue(value);
	}

	/**
	 * remove an attribute value
	 * @param attribdef
	 * @param value
	 * @throws Exception
	 */
	public void removeAttributeValue(IAttributeDefinition attribdef, Object value) throws APIException
	{
		ensureAttribute(attribdef).removeValue(value);
	}

    /**
     * Clear an attribute from cache based on definition.
     *
     * @param attribdef definition of attribute to clear;
     *                  if null, all attributes will be cleared from cache.
     */
    public void clearAttributeCache(IAttributeDefinition attribdef) {
        if (attribdef == null) {
            _attributes.clear();
        } else {
            _attributes.remove(resolveAttributeDefinition(attribdef).getToken());
        }
	}

	/**
	 * get an attribute based on definition
	 * @param attribdef
	 * @return
	 */
	public Attribute getAttribute(IAttributeDefinition attribdef) throws MetaException
	{
		return _attributes.get(resolveAttributeDefinition(attribdef).getToken());
	}

	private IAttributeDefinition resolveAttributeDefinition(IAttributeDefinition attribdef) throws MetaException
	{
		if (getAssetType().isA(attribdef.getAssetType()))
			return getAssetType().getAttributeDefinition(attribdef.getName());
		return attribdef;
	}

	/**
	 * accept changes to asset
	 */
	public void acceptChanges()
	{
		for(Attribute attrib : _attributes.values())
			attrib.acceptChanges();
	}

	/**
	 * reject changes to this asset
	 */
	public void rejectChanges()
	{
		for(Attribute attrib :_attributes.values())
			attrib.rejectChanges();
	}

	/**
	 * determine if something changed
	 * @return
	 */
	public boolean hasChanged() {
		for(Attribute attrib : _attributes.values())
			if(attrib.hasChanged())
				return true;
		return false;
	}

	public void loadAttributeValue(IAttributeDefinition attribdef, Object value) throws APIException
	{
		ensureAttribute(attribdef).loadValue(value);
	}

	public Attribute ensureAttribute (IAttributeDefinition attribdef) throws APIException
	{
		try {
			attribdef = resolveAttributeDefinition(attribdef);
		} catch (MetaException e) {
			throw new APIException("Cannot resolve Attribute", attribdef.getToken(), e);
		}
		Attribute attrib = _attributes.get(attribdef.getToken());
		if (attrib == null) {
			attrib = attribdef.isMultiValue() ? (Attribute) new MultiValueAttribute(attribdef, this) : new SingleValueAttribute(attribdef, this);
			_attributes.put(attribdef.getToken(), attrib);
		}
		return attrib;
	}
}
