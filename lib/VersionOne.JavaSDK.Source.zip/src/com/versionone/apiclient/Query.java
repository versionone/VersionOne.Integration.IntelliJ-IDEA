package com.versionone.apiclient;

import java.util.Date;

import com.versionone.Oid;
import com.versionone.apiclient.IAttributeDefinition.AttributeType;

/**
 * Represents a VersionOne API Query
 * @author Jerry D. Odenwelder Jr.
 */
public class Query {

	public static final Date MIN_DATE = new Date(0);

	private IAssetType _assetType = null;
	private AttributeSelection _selection = new AttributeSelection();
	private boolean _isHistorical;
	private Oid _oid;
	private IAttributeDefinition _parentRelation;
	private IFilterTerm _filter = null;
	private OrderBy _orderBy = new OrderBy();
	private Paging _paging = new Paging();
	private Date _asOf = MIN_DATE;
	private QueryFind _find = null;

	/**
	 * Create a query on an Asset Type
	 * @param assettype - type of asset you wish to query
	 */
	public Query(IAssetType assettype) {
		this(assettype, false);
	}

	/**
	 * Create a query on attribute in an Asset
	 * @param assettype - type of asset to query
	 * @param parentrelation - attribtue to query
	 */
	public Query(IAssetType assettype, IAttributeDefinition parentrelation){
		this(assettype, false, parentrelation);
	}

	/**
	 * Create a historical query on an asset
	 * @param assettype - type of asset to query
	 * @param historical - indicate if you want a history query
	 */
	public Query(IAssetType assettype, boolean historical) {
		this(assettype,historical,null);
	}

	/**
	 * Create a historical query on an attribute
	 * @param assettype - type of asset to query
	 * @param historical - indicate if you want a history query
	 * @param parentrelation - attribtue to query
	 */
	public Query(IAssetType assettype, boolean historical, IAttributeDefinition parentrelation)
	{
		_assetType = assettype;
		_isHistorical = historical;
		_oid = Oid.Null;
		_parentRelation = parentrelation;
		if (_parentRelation != null)
		{
			if (_parentRelation.getAttributeType() != AttributeType.Relation)
				throw new RuntimeException("Parent Relation must be a Relation Attribute Type");
			if (_parentRelation.isMultiValue())
				throw new RuntimeException("Parent Relation cannot be multi-value");
		}
	}

	/**
	 * Create a Query from an OID
	 * @param oid - oid to build query
	 * @param historical - do you want a historical query
	 */
	public Query(Oid oid, boolean historical)
	{
		if (oid.isNull())
			throw new RuntimeException("Invalid Query OID Parameter");
		else if(oid.hasMoment() && historical)
			throw new UnsupportedOperationException("Historical Query with Momented OID not supported");

		_isHistorical = historical;
		_assetType = oid.getAssetType();
		_oid = oid;
	}

	/**
	 * Create a data query from an IOD
	 * @param oid - oid to build query
	 */
	public Query(Oid oid)
	{
		this(oid, false);
	}

	/**
	 * Is this a historical query
	 * @return true if this query is historical
	 */
	public boolean isHistorical() {
		return _isHistorical;
	}

	/**
	 * get the asset type for the query
	 * @return IAssetType used for query
	 */
	public IAssetType getAssetType() {
		return _assetType;
	}

	/**
	 * Get the query oid
	 * @return Object Identifier used in query
	 */
	public Oid getOid() {
		return _oid;
	}

	/**
	 * The the AttributeDefinition
	 * @return IAttributedefinition used in query
	 */
	IAttributeDefinition getParentRelation() {
		return _parentRelation;
	}

	/**
	 * Get the attributes used in a 'sel'
	 * @return AttributeSelection for this query
	 */
	public AttributeSelection getSelection() {
		return _selection;
	}

	/**
	 * Set the attribute selection
	 * @param value
	 */
	public void setSelection(AttributeSelection value) {
		if(null != value)
			_selection = value;
	}

	/**
	 * Set a filter
	 * @param value
	 */
	public void setFilter(IFilterTerm value) {
		if(null != value) {
			_filter = value;
		}
	}

	/**
	 * Get the filter
	 * @return IFilterTerm for this query
	 */
	public IFilterTerm getFilter() {
		return _filter;
	}

	/**
	 * Set OrderBy information
	 * @param value
	 */
	public void setOrderBy(OrderBy value) {
		if(null != value)
			_orderBy = value;
	}

	/**
	 * Get the OrderBy information
	 * @return OrderBy terms for this query
	 */
	public OrderBy getOrderBy() {
		return _orderBy;
	}

	/**
	 * Set paging details
	 * @param value
	 */
	public void setPaging(Paging value) {
		if(null != value)
			_paging = value;
	}

	/**
	 * Get Paging details
	 * @return Paging for this query
	 */
	public Paging getPaging() {
		return _paging;
	}

	/**
	 * Set asOf Date
	 * @param value
	 */
	public void setAsOf(Date value) {
		_asOf = value;
	}

	/**
	 * Get asOf Date
	 * @return AsOf Date for this query
	 */
	public Date getAsOf() {
		return _asOf;
	}

	/**
	 * Create an 'And' query from an array of terms
	 * @param terms - all of these terms are and-ed together
	 * @return AndFilterTerm of the specified terms
	 */
	public static AndFilterTerm and(IFilterTerm[] terms) {
		return new AndFilterTerm(terms);
	}

	public static AndFilterTerm and(IFilterTerm term1, IFilterTerm term2) {
		return new AndFilterTerm(term1, term2);
	}

	/**
	 * Create an 'or' query from an array of terms
	 * @param terms - all of these terms are or-ed together
	 * @return OrFilterTerm of the specified terms
	 */
	public static OrFilterTerm or(IFilterTerm[] terms) {
		return new OrFilterTerm(terms);
	}

	public static OrFilterTerm or(IFilterTerm term1, IFilterTerm term2) {
		return new OrFilterTerm(term1, term2);
	}

	/**
	 * Create a FilterTerm for the specified attribute
	 * @param attribute - attribute for term
	 * @return FilterTerm for the specified attribute
	 */
	public static FilterTerm term(IAttributeDefinition attribute) {
		return new FilterTerm(attribute);
	}

	/**
	 * @return query find parameter
	 */
	public QueryFind getFind()
	{
		return _find;
	}

	/**
	 * @param value query find parameter
	 */
	public void setFind(QueryFind value)
	{
		_find = value;
	}
}
