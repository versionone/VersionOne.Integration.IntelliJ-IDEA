package com.versionone.apiclient.tests;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.Oid;
import com.versionone.apiclient.AndFilterTerm;
import com.versionone.apiclient.FilterTerm;
import com.versionone.apiclient.IFilterTerm;
import com.versionone.apiclient.OrFilterTerm;
import com.versionone.apiclient.Query;

public class QueryFilterTester extends MetaTesterBase {

	@Override
	protected String getMetaTestKeys() {
		return "QueryFilterTester";
	}

	@Test
	public void ToToken() throws Exception
	{
		FilterTerm term = Query.term(getWorkitemScope());
		term.Equal(new Object[]{getScopeOid(2)});
		Assert.assertEquals("Scope='Scope%3A2'", term.getToken());
	}

	@Test
	public void ToToken2() throws Exception
	{
		FilterTerm term1 = Query.term(getWorkitemParent());
		term1.Equal(new Object[]{getThemeOid(48)});

		FilterTerm term2 = Query.term(getWorkitemScope());
		term2.Equal(new Object[]{getScopeOid(2)});

		Assert.assertEquals("(Parent='Theme%3A48';Scope='Scope%3A2')", Query.and(new IFilterTerm[]{term1, term2}).getToken());
	}

	@Test
	public void Complex1() throws Exception
	{
		FilterTerm termA = Query.term(getWorkitemParent());
		termA.Equal(Oid.fromToken("Theme:5", getMeta()));
		termA.Equal(Oid.fromToken("Theme:6", getMeta()));

		FilterTerm termB = Query.term(getWorkitemScope());
		termB.Equal(Oid.fromToken("Scope:0", getMeta()));

		FilterTerm termC = Query.term(getWorkitemParent());
		termC.NotEqual(Oid.fromToken("Theme:7", getMeta()));
		termC.NotEqual(Oid.fromToken("Theme:8", getMeta()));

		FilterTerm termD = Query.term(getWorkitemScope());
		termD.NotEqual(Oid.fromToken("Scope:1", getMeta()));

		AndFilterTerm and1 = Query.and(termA, termB);
		AndFilterTerm and2 = Query.and(termC, termD);

		OrFilterTerm o = Query.or(and1, and2);

		Assert.assertEquals("((Parent='Theme%3A5','Theme%3A6';Scope='Scope%3A0')|(Parent!='Theme%3A7','Theme%3A8';Scope!='Scope%3A1'))", o.getToken());
	}

	@Test
	public void Complex2() throws Exception
	{
		FilterTerm termA = Query.term(getWorkitemToDo());
		termA.Greater(5);

		FilterTerm termB = Query.term(getWorkitemToDo());
		termB.Less(10);

		FilterTerm termC = Query.term(getWorkitemToDo());
		termC.GreaterOrEqual(20);

		FilterTerm termD = Query.term(getWorkitemToDo());
		termD.LessOrEqual(30);

		AndFilterTerm and1 = Query.and(termA, termB);
		AndFilterTerm and2 = Query.and(termC, termD);

		OrFilterTerm o = Query.or(and1, and2);

		Assert.assertEquals("((ToDo>'5';ToDo<'10')|(ToDo>='20';ToDo<='30'))", o.getToken());
	}


}
