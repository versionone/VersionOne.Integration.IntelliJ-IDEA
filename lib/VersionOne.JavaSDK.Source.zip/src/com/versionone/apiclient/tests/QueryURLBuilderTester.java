package com.versionone.apiclient.tests;

import java.util.Calendar;

import org.junit.Assert;
import org.junit.Test;

import com.versionone.DB;
import com.versionone.Oid;
import com.versionone.apiclient.APIException;
import com.versionone.apiclient.AndFilterTerm;
import com.versionone.apiclient.FilterTerm;
import com.versionone.apiclient.IAttributeDefinition;
import com.versionone.apiclient.IFilterTerm;
import com.versionone.apiclient.OrFilterTerm;
import com.versionone.apiclient.OrderBy;
import com.versionone.apiclient.Query;
import com.versionone.apiclient.QueryURLBuilder;
import com.versionone.apiclient.IAttributeDefinition.AttributeType;


public class QueryURLBuilderTester {

	@Test
	public void testSimpleQuery() throws APIException {
		QueryURLBuilder testMe = new QueryURLBuilder(new Query(new MockAssetType()));
		Assert.assertEquals("Data/Mock?sel=", testMe.toString());
	}

	@Test
	public void testSimpleQueryWithAttributes() throws APIException {

		Query query = new Query(new MockAssetType());
		query.getSelection().add(new MockAttributeDefinition("DefaultRole"));
		query.getSelection().add(new MockAttributeDefinition("Name"));
		query.getSelection().add(new MockAttributeDefinition("Nickname"));

		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=Mock.DefaultRole,Mock.Name,Mock.Nickname", testMe.toString());
	}

	@Test
	public void testFilter() throws APIException {
		Query query = new Query(new MockAssetType());
		FilterTerm term = new FilterTerm(new MockAttributeDefinition("Name"));
		term.Equal(new Object[] {"Jerry's Story"});
		query.setFilter(term);
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=&where=Name='Jerry%27%27s+Story'", testMe.toString());
	}

	@Test
	public void testFilterWithSpecialSymbol() throws APIException {
		Query query = new Query(new MockAssetType());
		FilterTerm term = new FilterTerm(new MockAttributeDefinition("Name"));
		term.Equal(new Object[] {"test & #"});
		query.setFilter(term);
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=&where=Name='test+%26+%23'", testMe.toString());
	}

	@Test
	public void testFilterWithSelect() throws APIException {
		Query query = new Query(new MockAssetType());
		query.getSelection().add(new MockAttributeDefinition("DefaultRole"));
		query.getSelection().add(new MockAttributeDefinition("Name"));
		query.getSelection().add(new MockAttributeDefinition("Nickname"));
		query.setFilter(new FilterTerm(new MockAttributeDefinition("Name"), FilterTerm.Operator.Equal, new Object[]{"Jerry"}));
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=Mock.DefaultRole,Mock.Name,Mock.Nickname&where=Name='Jerry'", testMe.toString());
	}

	@Test
	public void testAndQuery() throws APIException {
		Query query = new Query(new MockAssetType());
		query.getSelection().add(new MockAttributeDefinition("DefaultRole"));
		query.getSelection().add(new MockAttributeDefinition("Name"));
		query.getSelection().add(new MockAttributeDefinition("Nickname"));

		FilterTerm term1 = Query.term(new MockAttributeDefinition("Name"));
		term1.Equal(new Object[]{"Jerry"});
		FilterTerm term2 = Query.term(new MockAttributeDefinition("DefaultRole"));
		term2.Equal(new Object[]{"Observer"});
		AndFilterTerm term = Query.and(new IFilterTerm[]{term1, term2});
		query.setFilter(term);
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=Mock.DefaultRole,Mock.Name,Mock.Nickname&where=(Name='Jerry';DefaultRole='Observer')", testMe.toString());
	}

	@Test
	public void testOrQuery() throws APIException {
		Query query = new Query(new MockAssetType());
		query.getSelection().add(new MockAttributeDefinition("DefaultRole"));
		query.getSelection().add(new MockAttributeDefinition("Name"));
		query.getSelection().add(new MockAttributeDefinition("Nickname"));

		FilterTerm term1 = Query.term(new MockAttributeDefinition("Name"));
		term1.Equal(new Object[]{"Jerry"});
		FilterTerm term2 = Query.term(new MockAttributeDefinition("DefaultRole"));
		term2.Equal(new Object[]{"Observer"});
		OrFilterTerm term = Query.or(new IFilterTerm[]{term1, term2});
		query.setFilter(term);
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=Mock.DefaultRole,Mock.Name,Mock.Nickname&where=(Name='Jerry'|DefaultRole='Observer')", testMe.toString());
	}

	@Test
	public void testOrderBy() throws APIException
	{
		IAttributeDefinition estimateAttribute = new MockAttributeDefinition("Estimate");
		Query query = new Query(new MockAssetType());

		query.getSelection().add(new MockAttributeDefinition("Name"));
		query.getSelection().add(estimateAttribute);
		query.getOrderBy().minorSort(estimateAttribute, OrderBy.Order.Ascending);

		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=Mock.Name,Mock.Estimate&sort=Mock.Estimate", testMe.toString());
	}

	@Test
	public void testScalarQuery() throws APIException
	{
		Oid storyId = new Oid(new MockAssetType("Story"), 1094);
		Query query = new Query(storyId);
		query.getSelection().add(new MockAttributeDefinition("Name"));
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Story/1094/Name?", testMe.toString());
	}

	@Test
	public void testHistoryQuery() throws APIException {
		Oid storyId = new Oid(new MockAssetType("Story"), 1094, new DB.Int(15));
		Query query = new Query(storyId);
		query.getSelection().add(new MockAttributeDefinition("Name"));
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Story/1094/15/Name?", testMe.toString());
	}

	@Test(expected=UnsupportedOperationException.class)
	public void testQueryOnHistory() {
		Oid storyId = new Oid(new MockAssetType("Story"), 1094, new DB.Int(15));
		@SuppressWarnings("unused")
		Query query = new Query(storyId, true);
	}


	@Test
	public void testParentRelation() throws Exception {
		Query query = new Query(new MockAssetType("Task"), new MockAttributeDefinition("Story", AttributeType.Relation));
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Task?sel=Mock.Story", testMe.toString());
	}

	@Test
	public void testPaging() throws APIException {
		Query query = new Query(new MockAssetType());
		query.getSelection().add(new MockAttributeDefinition("Name"));
		query.getPaging().setStart(5);
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=Mock.Name&page=2147483647,5", testMe.toString());

		query.getPaging().setPageSize(10);
		testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=Mock.Name&page=10,5", testMe.toString());

	}

	@Test
	public void testAsOf() throws APIException {
		Calendar testDate = Calendar.getInstance();
		// date we want is 10/1/2007 at 3:00pm
		testDate.set(2007, 9, 1, 3, 00, 00);
		Query query = new Query(new MockAssetType());
		query.setAsOf(testDate.getTime());
		QueryURLBuilder testMe = new QueryURLBuilder(query);
		Assert.assertEquals("Data/Mock?sel=&asof=2007-10-01T03:00:00", testMe.toString());
	}
}
