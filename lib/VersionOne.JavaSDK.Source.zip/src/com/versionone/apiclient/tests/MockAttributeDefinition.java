package com.versionone.apiclient.tests;

import com.versionone.apiclient.IAssetType;
import com.versionone.apiclient.IAttributeDefinition;
import com.versionone.apiclient.IFilterTerm;
import com.versionone.apiclient.MetaException;

/**
 * AttributeType used for testing
 * @author jerry
 */
class MockAttributeDefinition implements IAttributeDefinition {
	String _name;
	AttributeType _type = AttributeType.Text;
	

	public MockAttributeDefinition(String attributeName, AttributeType type) {
		_name = attributeName;
		_type = type;
	}
	
	public MockAttributeDefinition(String attributeName) {
		_name = attributeName;
	}

	public Object coerce(Object value) throws MetaException {
		return value;
	}

	public IAssetType getAssetType() throws MetaException {
		return null;
	}

	public AttributeType getAttributeType() {
		return _type;
	}

	public IAttributeDefinition getBase() throws MetaException {
		// TODO Auto-generated method stub
		return null;
	}

	public String getDisplayName() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getName() {
		return _name;
	}

	public IAssetType getRelatedAsset() throws MetaException {
		// TODO Auto-generated method stub
		return null;
	}

	public String getToken() {
		return "Mock."+ _name;
	}

	public boolean isMultiValue() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isReadOnly() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isRequired() {
		// TODO Auto-generated method stub
		return false;
	}

	public IAttributeDefinition aggregate(
			com.versionone.apiclient.IAttributeDefinition.Aggregate aggregate) {
		// TODO Auto-generated method stub
		return null;
	}

	public IAttributeDefinition downcast(IAssetType assetType) {
		// TODO Auto-generated method stub
		return null;
	}

	public IAttributeDefinition filter(IFilterTerm filter) {
		// TODO Auto-generated method stub
		return null;
	}

	public IAttributeDefinition join(IAttributeDefinition joined) {
		// TODO Auto-generated method stub
		return null;
	}

}