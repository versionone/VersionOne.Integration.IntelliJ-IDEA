package com.versionone.apiclient;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Responsible for building the query
 * @author jerry
 *
 */
public class QueryURLBuilder
{
	private String _url = null;

	public QueryURLBuilder(Query query) throws APIException
	{
		List<String> querystringparts = new ArrayList<String>();
		List<String> pathparts = new ArrayList<String>();

		if (query.isHistorical())
			pathparts.add("Hist");
		else
			pathparts.add("Data");

		pathparts.add(query.getAssetType().getToken());

		if (!query.getOid().isNull())
			pathparts.add(query.getOid().getKey().toString());

		if (query.getOid().hasMoment())
			pathparts.add(query.getOid().getMoment().toString());

		if (query.getParentRelation() != null)
			query.getSelection().add(query.getParentRelation());

		if (query.getSelection().size() == 1 && !query.getOid().isNull())
			pathparts.add(query.getSelection().get(0).getName());
		else if (query.getSelection().size() > 0)
			querystringparts.add("sel=" + query.getSelection().getToken());
		else
			querystringparts.add("sel=");

		IFilterTerm filter2token = query.getFilter();
		if (filter2token != null)
			querystringparts.add("where=" + filter2token.getToken());

		if (query.getOrderBy().size() > 0)
			querystringparts.add("sort=" + query.getOrderBy().getToken());

		if (query.getPaging().getStart() != 0 || query.getPaging().getPageSize() != Integer.MAX_VALUE)
			querystringparts.add("page=" + query.getPaging().getToken());

		if(query.getAsOf().compareTo(Query.MIN_DATE) > 0) {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			querystringparts.add("asof=" + df.format(query.getAsOf()));
		}

		if (query.getFind() != null){
			String findText = query.getFind().text;
			if (findText != null && findText.trim().length()!=0){
				querystringparts.add("find=" + query.getFind().text);
				if (query.getFind().attributes.size() > 0){
					querystringparts.add("findin=" + query.getFind().attributes.getToken());
				}
			}
		}

		String path = TextBuilder.join(pathparts, "/");
		String querystring = TextBuilder.join(querystringparts, "&");

		_url = path + ( ((querystring != null) ? "?" + querystring : ""));
		_url = _url.replace(" ","%20");
	}

	@Override
	public String toString() {
		return _url;
	}
}