package com.versionone.apiclient;

/**
 * Combine terms in a filter using 'or'
 * @author jerry
 *
 */
public class OrFilterTerm extends GroupFilterTerm {

	/**
	 * Create filter collection of terms
	 * @param terms
	 */
	public OrFilterTerm(IFilterTerm[] terms) {
		super(terms);
	}

	/**
	 * Create filter with just two terms
	 * @param term1
	 * @param term2
	 */
	public OrFilterTerm(IFilterTerm term1, IFilterTerm term2) {
		super(term1, term2);
	}

	@Override
	String getTokenSeperator() {
		return "|";
	}

}
